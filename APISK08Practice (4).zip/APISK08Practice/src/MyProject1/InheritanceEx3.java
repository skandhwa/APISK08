package MyProject1;

class D5
{
	void display()
	{
		System.out.println("Hello");
	}
}

class D6 extends D5
{
	void test()
	{
		System.out.println("Hi");
	}
}

class D7 extends D5
{
	void message()
	{
		System.out.println("Java");
	}
}



public class InheritanceEx3 {

	public static void main(String[] args) {
		
		D6 obj=new D6();
		obj.test();
		obj.display();
		

	}

}
