package MISC;

import static io.restassured.RestAssured.given;

import java.io.File;

import io.restassured.RestAssured;

public class FileasInput {

	public static void main(String[] args) {
	
		
		
       File f=new File("D:\\RandomDataGeneration.txt");
       File f2=new File("D:\\RandomDataGeneration.txt");
		
		RestAssured.baseURI="http://httpbin.org";
		
	String Response=	given().log().all().
		headers("Content-Type","multipart/form-data")
		.multiPart("File",f)
		.multiPart("File",f2)
		.when().post("post")
		.then().log().all().extract().response().asString();
		
		System.out.println(Response);
		
			
		///  E:\\MyTest2.txt
		

	}

}
