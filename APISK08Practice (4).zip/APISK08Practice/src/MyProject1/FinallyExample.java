package MyProject1;

public class FinallyExample {

	public static void main(String[] args) {
		
		try
		{
		int x=10;
		int y=2;
		
		int z=x/y;
		
		System.out.println(z);
		}
		
//		catch(Exception e)
//		{
//			System.out.println("Caught with  "+e);
//		}
		
		finally
		
		{
			int p=20;
			int q=30;
			int r=p*q;
			System.out.println(r);
		}
		
		
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);
		

	}

}
