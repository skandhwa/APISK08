package MyProject1;

abstract class Employee2
{
	void displayId()
	{
		System.out.println("My id");
	}
	
	abstract void salary();
	
	
}

class P1 extends Employee2
{
	void salary()
	{
		int basic=30000;
		int hra=32000;
		
		
	}
}




public class AbstractClassRealTime {

	public static void main(String[] args) {
		
		
		
		

	}

}
