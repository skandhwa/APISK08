package MyProject1;

interface I10
{
	static int sum(int x,int y)
	{
		return x+y;
	}
	
	default void display()
	{
		System.out.println("Hello");
	}
	
}


class C11 implements I10
{
	
}


public class interfaceWithStatic {

	public static void main(String[] args) {
		
	System.out.println(I10.sum(23,45));	
	
	I10 ref=new C11();
	ref.display();
	
	
	
	
	
	}

}
