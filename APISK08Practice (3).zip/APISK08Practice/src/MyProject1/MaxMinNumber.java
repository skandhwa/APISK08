package MyProject1;

class Test4
{
public static int maxorMin(int []a,int total)
{
	for(int i=0;i<total;i++)
	{
		for(int j=i+1;j<total;j++)
		{
			if(a[i]>a[j])//
			{
				int temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
	}
	
	return a[total-4];///
	
	
	
	
}

}



public class MaxMinNumber {

	public static void main(String[] args) {
		
		int []a= {12,1,7,14,22,4};
		int y=a.length;
		
	System.out.println(Test4.maxorMin(a, y));
		
		
		
		
		
		

	}

}
