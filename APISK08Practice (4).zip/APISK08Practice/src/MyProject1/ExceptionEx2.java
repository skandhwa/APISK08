package MyProject1;

public class ExceptionEx2 {

	public static void main(String[] args) {
		
		try
		{
		String str=null;
		
		int x=str.length();
		}
		
		catch(NullPointerException e)
		{
			System.out.println("caught with  "+e);
		}
		
		
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);
		

	}

}
