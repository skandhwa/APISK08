package MyProject1;

public class StringMethods6 {

	public static void main(String[] args) {
		
		String str="selenium java tools";
		
		
//		String str1=str.replace("java", "python");
//		
//		System.out.println(str1);
		
//		str=str.replaceAll('j','p');
//		System.out.println(str);
		

	}

}
