//package MyProject1;
//
//class Vehicle
//{
//	 final static int speed=40;
//	
//	public static void run()
//	{
//		speed=60;
//		System.out.println(speed);
//	}
//	
//}
//public class FinalKeyWordEx {
//
//	public static void main(String[] args) {
//		
//		Vehicle obj=new Vehicle();
//		obj.run();
//		
//
//	}
//
//}
