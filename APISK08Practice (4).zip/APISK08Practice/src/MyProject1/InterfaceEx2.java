package MyProject1;

interface I4
{
	void display();
	void test();
}

interface I5 extends I4
{
	void message();
}

class G4 implements I5
{
	public void display()
	{
		
	}
	public void test()
	{
		
	}
	
	public void message()
	{
		
	}
}





public class InterfaceEx2 {

	public static void main(String[] args) {
		
		
		

	}

}
