package MapExamples;

import java.util.LinkedHashMap;
import java.util.Map;

public class HashMapEx3 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		mp.put(12, "tom");
		mp.put(32, "harry");
		mp.put(42, "matt");
		mp.put(19, "john");
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
		
		

	}

}
