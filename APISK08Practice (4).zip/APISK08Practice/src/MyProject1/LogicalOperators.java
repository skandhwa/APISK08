package MyProject1;

public class LogicalOperators {

	public static void main(String[] args) {
		
		int a=10,b=15,c=30;
		
		
		if(a>b || c<b || a<c)
		{
			System.out.println("Yes");
		}
		
		else
		{
			System.out.println("No");
		}
		

	}

}
