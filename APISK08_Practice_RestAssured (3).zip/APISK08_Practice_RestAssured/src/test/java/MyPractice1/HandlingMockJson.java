package MyPractice1;

import MockResponse.CourseDetails;
import io.restassured.path.json.JsonPath;

public class HandlingMockJson {

	public static void main(String[] args) {
		
		JsonPath js=new JsonPath(CourseDetails.getCourseDetails());
		
		///Print No of courses returned by API

	int courseSize=	js.getInt("courses.size()");
	System.out.println("Total number of courses is  "+courseSize);
	
	//Print Purchase Amount

	int purchaseAmount=js.getInt("dashboard.purchaseAmount");
	System.out.println("The total purchase amount is  "+purchaseAmount);
		
	//Print Title of the first course
	
	String titleFirstCourse=js.getString("courses[0].title");
	System.out.println("Title of first course is  "+titleFirstCourse);
	
	
	//Print All course titles and their respective Prices
	
	System.out.println("Courses titles and their respective Prices are as below ");
	
	for(int i=0;i<courseSize;i++)
	{
	String courseTitle=	js.getString("courses["+i+"].title");
	int coursePrice=	js.getInt("courses["+i+"].price");
	System.out.println(courseTitle +" "+coursePrice);
		
	}
	

	
		

	}

}
