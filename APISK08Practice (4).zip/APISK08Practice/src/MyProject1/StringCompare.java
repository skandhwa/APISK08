package MyProject1;

public class StringCompare {

	public static void main(String[] args) {
		
		String str="ASelenium";///
		
		String str1="selenium";
//		
//		boolean flag=str.equalsIgnoreCase(str1);
//		System.out.println(flag);
		
	int x=	str.compareTo(str1);
	
	System.out.println(x);
		

	}

}
