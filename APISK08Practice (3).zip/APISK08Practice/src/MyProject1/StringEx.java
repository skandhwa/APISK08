package MyProject1;

public class StringEx {

	public static void main(String[] args) {
		
		String str="Saurabh";
		
	str=	str.concat("Trainer");
		
		System.out.println(str);
		

	}

}
