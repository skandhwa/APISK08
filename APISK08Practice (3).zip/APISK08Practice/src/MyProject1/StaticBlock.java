package MyProject1;


public class StaticBlock {
	
	
	static
	{
		System.out.println("Hello");
	}
	

	public static void main(String[] args) {
		
		System.out.println("Java");
		

	}

}
