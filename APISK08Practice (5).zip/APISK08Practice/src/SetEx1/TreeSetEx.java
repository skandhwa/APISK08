package SetEx1;

import java.util.TreeSet;

public class TreeSetEx {

	public static void main(String[] args) {
		
		TreeSet<Integer> s1=new TreeSet<Integer>();
		
		s1.add(123);
		s1.add(198);
		s1.add(106);
		s1.add(108);
		
		System.out.println(s1);
		
		System.out.println("Reversing the order");
		System.out.println(s1.descendingSet());
		
		
		
		

	}

}
