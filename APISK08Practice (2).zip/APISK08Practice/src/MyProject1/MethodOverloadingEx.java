package MyProject1;

class E6
{
	static int sum(int x,int y,int z)
	{
		return x+y+z;
	}
	
	static float sum(int a,int b,float c)
	{
		return a+b+c;
	}
}




public class MethodOverloadingEx {

	public static void main(String[] args) {
		
	System.out.println(E6.sum(34, 56, 90));	
		

	}

}
