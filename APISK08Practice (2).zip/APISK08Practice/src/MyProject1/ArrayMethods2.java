package MyProject1;

import java.util.Arrays;

public class ArrayMethods2 {

	public static void main(String[] args) {
		
		int []a= {102,356,943,978};
		
		int []b= {102,356,1043,1078};
		
	boolean flag=	Arrays.equals(a,b);
	
	System.out.println(flag);
	
	
	 int x=Arrays.compare(a,b);
	 
	 System.out.println(x);
	 
	
		
	
		

	}

}
