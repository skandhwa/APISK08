package SetEx1;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetExample1 {

	public static void main(String[] args) {
		
		Set<Integer> s1= new LinkedHashSet<Integer>();
		s1.add(67);
		s1.add(99);
		s1.add(102);
		s1.add(34);
		s1.add(67);
		
		System.out.println(s1);
		
		

	}

}
