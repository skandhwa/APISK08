package MapExamples;

import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class MapEx4 {

	public static void main(String[] args) {
		
		
		TreeMap<Integer,String> mp=new TreeMap<Integer,String>();
		mp.put(12, "tom");
		mp.put(20, "harry");
		mp.put(42, "matt");
		mp.put(9, "john");
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		System.out.println();
		System.out.println();
		System.out.println(mp.descendingMap());
	  
		
		

	}

}
