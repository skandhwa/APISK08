package CollectionsPractice;

import java.util.Stack;

public class StackEx {

	public static void main(String[] args) {
		
		Stack<Object> s1=new Stack<Object>();
		
		s1.push(56);
		s1.push("apple");
		s1.push(99);
		s1.push(60000f);
		
		
		s1.pop();
		
		System.out.println(s1);
		
		System.out.println	(s1.peek());
		


	}

}
