package MyProject1;

interface I8
{
	void test();
}
interface I9
{
    void display();
}

class C10 implements I8,I9
{
	public void test()
	{
		System.out.println("Hello");
	}
	
	public void display()
	{
		System.out.println("Hi");
	}
}

public class MultipleInheritance {

	public static void main(String[] args) {
		
		I8 ref=new C10();
		ref.test();
		I9 ref1=new C10();
		ref1.display();
		
		
		C10 obj=new C10();
		obj.test();
		obj.display();

		
	}

}
