package MyProject1;

public class StringMethods3 {

	public static void main(String[] args) {
		
//		String str="Saurabh@Test@Trainer@java";
//		
//	String []s1=	str.split("@");
//	
//	System.out.println(s1[3]);
		
		
		String str="test newtools";
		
	int x=	str.indexOf('o',-5);
	
	System.out.println(x);
		
		

	}

}
