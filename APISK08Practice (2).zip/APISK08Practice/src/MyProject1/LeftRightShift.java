package MyProject1;

public class LeftRightShift {

	public static void main(String[] args) {
		
		
		int x=1000;
		
		System.out.println(x>>4);  /// 20*2pow2
		

	}

}
