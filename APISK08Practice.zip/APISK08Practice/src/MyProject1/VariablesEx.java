package MyProject1;

class A
{
	int x=10;
	
	void display()
	{
		
		int y=x+20;
		System.out.println(y);
	}
	
	void test()
	{
		int a=10;
		int b=a+x;
		System.out.println(b);
	}
}


public class VariablesEx {

	public static void main(String[] args) {
		

	}

}
