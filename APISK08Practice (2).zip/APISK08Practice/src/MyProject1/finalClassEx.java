//package MyProject1;
//
//final class E7
//{
//	void display()
//	{
//		System.out.println("Hello");
//	}
//}
//
//class E8 extends E7
//{
//	void test()
//	{
//		System.out.println("Hi");
//	}
//}
//
//
//
//public class finalClassEx {
//
//	public static void main(String[] args) {
//		
//		E8 obj=new E8();
//		obj.display();
//		obj.test();
//		
//
//	}
//
//}
