package MyProject1;

class D2
{
	void test()
	{
		System.out.println("Hi");
	}
	
	void display()
	{
		System.out.println("Hello");
	}
}


class D3 extends D2
{
	void message()
	{
		System.out.println("This is saurabh");
	}
}

class D4 extends D3
{
	void test1()
	{
		System.out.println("Hey this is java");
	}
}


public class InheritanceEx2 {

	public static void main(String[] args) {
		
		D4 obj=new D4();
		obj.test();
		obj.test1();
		obj.display();
		obj.message();
		
		

	}

}
