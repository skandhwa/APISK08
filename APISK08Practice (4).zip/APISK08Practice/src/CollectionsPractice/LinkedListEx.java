package CollectionsPractice;

import java.util.LinkedList;
import java.util.Vector;

public class LinkedListEx {

	public static void main(String[] args) {
		
		LinkedList<Integer> li=new LinkedList<Integer>();
		
		li.add(34);
		li.add(78);
		li.add(99);
		li.add(103);
		
		
		Vector<Integer> v1=new Vector<Integer>();
		v1.add(34);
		
		
		

	}

}
