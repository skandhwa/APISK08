package MapExamples;

import java.util.HashMap;
import java.util.Map;

public class HashMapEx1 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(12,"apple");
		mp.put(42,"banana");
		mp.put(2,"melon");
		mp.put(9,"kiwi");
		mp.put(null, null);
		mp.put(null,"orange");
		mp.put(62,"banana");
		mp.put(82,"melon");
		mp.put(19,"kiwi");
		
		
		//System.out.println(mp);
		
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
		
		
		

	}

}
