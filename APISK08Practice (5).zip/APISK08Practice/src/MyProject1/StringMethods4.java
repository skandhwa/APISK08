package MyProject1;

public class StringMethods4 {

	public static void main(String[] args) {
		
		
		String str="1234sauTESTrabhtest@#$%^";
		
	str=	str.replaceAll("[^A-Z]", "");
		
	System.out.println(str);	
	
		

	}

}
