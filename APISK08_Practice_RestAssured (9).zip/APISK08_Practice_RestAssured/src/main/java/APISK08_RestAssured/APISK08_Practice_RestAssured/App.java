package APISK08_RestAssured.APISK08_Practice_RestAssured;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
