package CollectionsPractice;

import java.util.Arrays;
import java.util.List;

public class ArrayToArrayList {

	public static void main(String[] args) {
		
		String []city = {"Delhi" ,"Hyderabad","Bangalore","Mumbai"};
		
		List li=Arrays.asList(city);
		
		System.out.println(li);
		
		
		
		
	}

}
