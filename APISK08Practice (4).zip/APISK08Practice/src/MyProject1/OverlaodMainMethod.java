package MyProject1;

public class OverlaodMainMethod {
	
	public static void main(String str)
	{
		int x=str.length();
		System.out.println(x);
	}
	
	

	public static void main(String[] args) {
		
		System.out.println("Hello");
		

	}

}
