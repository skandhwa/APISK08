package MapExamples;

import java.util.HashMap;
import java.util.Map;

public class HashMapEx2 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(12, "tom");
		mp.put(32, "harry");
		mp.put(42, "matt");
		mp.put(19, "john");
		System.out.println(mp);
		
		
		int x=mp.size();
		System.out.println(x);
		
		
		Map<Integer,String> mp2=new HashMap<Integer,String>();
		mp2.put(43, "zen");
		mp2.put(65, "elisa");
		mp2.put(42, "matt");
		mp2.put(19, "john");
		
		
	//System.out.println(mp.get(19));	
	
//            mp.putAll(mp2);   
//      
//      System.out.println(mp);
      
    boolean flag=  mp.containsKey(132);
    System.out.println(flag);
    
    mp.remove(42);
		
		
    System.out.println(mp)	;
    
    mp.replace(19, "kelly");
    
    System.out.println(mp);
    
    
    
		

	}

}
