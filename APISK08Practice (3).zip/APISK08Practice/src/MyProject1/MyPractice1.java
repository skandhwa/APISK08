package MyProject1;

public class MyPractice1 {

	public static void main(String[] args) {
		
		int x=5;
		
		int y=8;
		
		int z=7;
		
		
		int res =  z-- + x-- + y--  + --z + --y + --x;
		
		
		//// 7 + 5 +8 + 5 + 6+ 3
		
		 
	
		
		
		///x=4  y=7,, z=6
		
		System.out.println(res);
		
		

	}

}
