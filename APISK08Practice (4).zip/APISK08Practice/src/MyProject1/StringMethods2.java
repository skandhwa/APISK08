package MyProject1;

public class StringMethods2 {

	public static void main(String[] args) {
		
		String str="Republic";
//	String str1=	str.substring(5);
//	System.out.println(str1);
		
		String str2= str.substring(9,8);
		System.out.println(str2);
		
		
		
		
	}

}
