package SetEx1;

import java.util.HashSet;
import java.util.Set;

public class SetExample2 {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		
		s1.add("orange");
		s1.add("apple");
		s1.add("melon");
		s1.add("guava");
		
       Set<String> s2=new HashSet<String>();
		
		s2.add("orange");
		s2.add("apple");
		s2.add("melon");
		s2.add("guava");
		s2.add("papaya");
		
//		s1.addAll(s2);
//		System.out.println(s1); ///union of set
		
		
//		s1.removeAll(s2);
//		System.out.println(s1); //difference of set
		
		
//		s1.retainAll(s2);
//		System.out.println(s1);///intersection of two set
		
//	boolean flag=	s2.containsAll(s1);
//		
//	System.out.println(flag);
		
		
//	boolean flag=	s1.contains("melon");
//	System.out.println("Does set contains melon "+flag);
		
//		s1.remove("guava");
//		System.out.println(s1);
		
		
		
		
		

	}

}
