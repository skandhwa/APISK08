package MyProject1;

class Student
{
	String name;
	int id;
	float salary;
	boolean isMarried;
	
	Student(String name,int id,float salary)
	{
		this.name=name;
		this.id=id;
		this.salary=salary;
	}
	
	
	Student(String name,int id,float salary,boolean isMarried)
	{
		this(name,id,salary);
		this.isMarried=isMarried;
	}
	
	void display()
	{
		System.out.println(name+"  "+id+"  "+salary+"  "+isMarried);
	}
	}
public class ThisKeywordEx {

	public static void main(String[] args) {
		
		Student obj=new Student("Rohan",1234,80000f,true);
		obj.display();
		
		

	}

}
