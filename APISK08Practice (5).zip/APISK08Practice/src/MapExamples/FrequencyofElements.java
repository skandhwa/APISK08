package MapExamples;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyofElements {

	public static void main(String[] args) {
		
		int []a= {13,14,13,13,15,14};
		
		Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();
		
		for(Integer x:a)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));  ////mp.put(13, 1+1 )//mp.put(13,2)//mp.put(13,3)
			}
			else
			{
				mp.put(x, 1);
			}
			
		}
		
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
		int maxCount = 0;
		int minCount = 9999;
		int maxElement = -1;
		int minElement = -1;

		for (Map.Entry<Integer,Integer> entry : mp.entrySet()) {
		    int key = entry.getKey();///key=13   //key=14  /// key=15
		    int count = entry.getValue();///count=3  ///count=2  ///count=1

		    if (count > maxCount) {  /// 3>0   ///  2 > 3 // 1 >3
		        maxCount = count;///maxcount=3
		        maxElement = key;////maxelement=13
		    }
		    if (count < minCount) {  /// 3<9999  /// 2<3   /// 1 < 2
		        minCount = count;  ////mincount=3 ///mincount=2  ///mincount=1
		        minElement = key; ////minelement=13 ///minelement=14 ////minElement=15
		    }
		}

		// Print results
		System.out.println("Max occurring element: " + maxElement + " (count = " + maxCount + ")");
		System.out.println("Min occurring element: " + minElement + " (count = " + minCount + ")");
		
		
		
		

	}

}
