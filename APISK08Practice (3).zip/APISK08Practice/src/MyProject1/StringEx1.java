package MyProject1;

public class StringEx1 {

	public static void main(String[] args) {
		
		String str="Republic$%^&";//String literal
		
		String str1=new String("India");//By the help of new keyword
		
		

	}

}
