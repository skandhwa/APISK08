package MapExamples;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyofWord {

	public static void main(String[] args) {
		
		
		String str="Tip Tap toe tip tip tap";
		
		str=str.toLowerCase();
		
		Map<String,Integer> mp=new LinkedHashMap<String,Integer>();
		
		String []s1= str.split(" ");
		
		for(String x:s1)
		{
			if(mp.containsKey(x))
			{
				mp.put(x,(mp.get(x)+1));
			}
			
			else
			{
				mp.put(x,1);
			}
		}
		
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
		
		
		
		int maxCount = 0;
		int minCount = 9999;
		String maxElement = "abcd";
		String minElement = "efgh";

		for (Map.Entry<String,Integer> entry : mp.entrySet()) {
		    String key = entry.getKey();///key=tip // key=tap
		    int count = entry.getValue();/// count=3//count=2

		    if (count > maxCount) {  /// 3>0  //2>3
		        maxCount = count;/// maxcount=3
		        maxElement = key;////maxelement=tip
		    }
		    if (count < minCount) {  ///  3<9999  // 2<3
		        minCount = count;  //// minCount=3 ///mincount=2
		        minElement = key; //// minElement=tip///minelement=tap
		    }
		}

		// Print results
		System.out.println("Max occurring element: " + maxElement + " (count = " + maxCount + ")");
		System.out.println("Min occurring element: " + minElement + " (count = " + minCount + ")");
		
		
		

	}

}
