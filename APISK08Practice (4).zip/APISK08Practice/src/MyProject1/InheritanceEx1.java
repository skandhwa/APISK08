package MyProject1;

class C1
{
	void display()
	{
		System.out.println("Hello");
	}
	
	void message()
	{
		System.out.println("Hi");
	}
	
}

class C2 extends C1
{
	void test()
	{
		System.out.println("Hey");
	}
}


public class InheritanceEx1 {

	public static void main(String[] args) {
		
		C2 obj=new C2();
		obj.display();
		obj.test();
		obj.message();
		

	}

}
