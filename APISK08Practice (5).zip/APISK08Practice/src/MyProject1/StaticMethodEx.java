package MyProject1;

class E3
{
	static int x=10;
	
	static void display()
	{
		System.out.println("Hello");
		x=15;
	}
}



public class StaticMethodEx {

	public static void main(String[] args) {
		
		E3.display();
		
		

	}

}
