package CollectionsPractice;

import java.util.ArrayList;
import java.util.List;

public class ListEx2 {

	public static void main(String[] args) {
		
		List<Object> li=new ArrayList<Object>();
		
		li.add(34);
		li.add("apple");
		li.add('A');
		li.add(false);
		

	}

}
