package StepDefinition11;

import static io.restassured.RestAssured.given;

import org.testng.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;

import Utilities.CreateUserData;
import Utilities.FetchDataFromProperty;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;


public class StepDefinition11 {
	
	String base_URI=FetchDataFromProperty.readDataFromProperty().getProperty("base_uri");
	
	RequestSpecification req,res;
	ResponseSpecification respec;
	Response response;
	
	
	
	
	
	
	
	@Given("user starts sending API requests")
	public void user_starts_sending_api_requests() {
		
		req=new RequestSpecBuilder().setBaseUri(base_URI)
				.setContentType(ContentType.JSON).build();
		
		
		
	  
	}

	@When("user enters the payload data")
	public void user_enters_the_payload_data() throws JsonProcessingException {
		
		res= given().log().all().headers("x-api-key","reqres-free-v1")
				.relaxedHTTPSValidation().spec(req)
				.body(CreateUserData.createUser());
				
				
				
		
		
	    
	}

	@When("user submits the payload with an endpoint as {string}")
	public void user_submits_the_payload_with_an_endpoint_as(String endpoint) {
		
		respec= new ResponseSpecBuilder().build();
		
	response=	res.when().post(endpoint).then().log().all().extract().response();
		
		
		
	    
	}

	@Then("validate user gets created and corresponding status code is {string}")
	public void validate_user_gets_created_and_corresponding_status_code_is(String status_code) {
	    
		
		long resTime=response.getTime();
		if(resTime>5000)
		{
			throw new ArithmeticException ("Longer than expected response");
			
		}
		
		else
		{
			System.out.println("response time is within Threshold");
		}
		
		Integer code=	response.getStatusCode();
	    String Actual_Code=code.toString();
	    Assert.assertEquals(Actual_Code, status_code);
	
	    JsonPath js=new JsonPath(response.asString());
	   String CreatedDate= js.getString("createdAt");
			
	   
			
		
		
		
		
	}

}
