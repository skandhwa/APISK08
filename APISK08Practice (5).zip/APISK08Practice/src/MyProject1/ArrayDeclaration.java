package MyProject1;

public class ArrayDeclaration {

	public static void main(String[] args) {
		
		int[]a = {2,3,4,5,6};
		
		int []b=new int[] {23,56,78,99};
		
		String []s1= {"saurabh","gaurabh"};
		
		
		for(int i=0;i<a.length;i++)///i=0,0<5
		{
			System.out.print(a[i]+" ");//a[0],a[1],a[2],a[3],a[4]
		}
		
		
		
		

	}

}
